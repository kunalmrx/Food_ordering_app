package modal

data class Faq (
    var question:String,
    var answer:String
)