package modal

data class Menu(
    val id:String,
    val dish:String,
    val price: Int
)
