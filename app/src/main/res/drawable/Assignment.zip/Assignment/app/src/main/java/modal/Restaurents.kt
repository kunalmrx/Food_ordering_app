package modal

data class Restaurents(
    val id:String,
    val restName:String,
    val restCost:String,
    val restRating:String,
    val imgRestaurents: String
)